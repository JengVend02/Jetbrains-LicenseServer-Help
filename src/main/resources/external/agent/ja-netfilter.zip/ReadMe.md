## 破解包下载
官网 `https://jetbrains.ankio.net/license` 或 [直接下载](https://jetbrains.ankio.net/static/ja-netfilter.zip) 或 [ja-netfilter-java25-neo](https://gitee.com/ja-netfilter/ja-netfilter/releases/tag/2025.3.0)

## 解压破解包
解压[ja-netfilter.zip](../ja-netfilter.zip)并放入`D:\ALL\BC\jetbrains`

## 破解包路径
```text
D:\ALL\BC\jetbrains\ja-netfilter
```

## 有效版本：
```text
ideaIU-2021.2.3
ideaIU-2024.1.1
ideaIU-2024.3.5
datagrip-2023.3.2
```

## install-current-user.vbs 都干了什么
```text
1.修改【破解包路径\vmoptions】文件夹里的所有文件 统一在末尾添加(-javaagent:【ja-netfilter.jar绝对路径】=jetbrains)
2.把【破解包路径\vmoptions】文件夹里的所有文件 添加到用户变量(此电脑->属性->高级系统设置->环境变量->用户变量(新建))
    变量名 = ${【破解包路径\vmoptions】文件夹下的文件名(大写且不含后缀.vmoptions)}_VM_OPTIONS 例如(IDEA_VM_OPTIONS)
    变量值 = 【破解包路径\vmoptions】文件夹下的文件的绝对路径
    重启电脑之后 对应软件的【自定义虚拟机选项】就会变成环境变量中的路径 比如打开idea就会使用IDEA_VM_OPTIONS变量路径下的idea.vmoptions
```

## 环境变量一览(用户变量)
| 变量名                         | 变量值                                        |
|:----------------------------|:-------------------------------------------|
| APPCODE_VM_OPTIONS          | 破解包路径\vmoptions\appcode.vmoptions          |
| CLION_VM_OPTIONS            | 破解包路径\vmoptions\clion.vmoptions            |
| DATAGRIP_VM_OPTIONS         | 破解包路径\vmoptions\datagrip.vmoptions         |
| DATASPELL_VM_OPTIONS        | 破解包路径\vmoptions\dataspell.vmoptions        |
| DEVECOSTUDIO_VM_OPTIONS     | 破解包路径\vmoptions\devecostudio.vmoptions     |
| GATEWAY_VM_OPTIONS          | 破解包路径\vmoptions\gateway.vmoptions          |
| GOLAND_VM_OPTIONS           | 破解包路径\vmoptions\goland.vmoptions           |
| IDEA_VM_OPTIONS             | 破解包路径\vmoptions\idea.vmoptions             |
| JETBRAINS_CLIENT_VM_OPTIONS | 破解包路径\vmoptions\jetbrains_client.vmoptions |
| JETBRAINSCLIENT_VM_OPTIONS  | 破解包路径\vmoptions\jetbrainsclient.vmoptions  |
| PHPSTORM_VM_OPTIONS         | 破解包路径\vmoptions\phpstorm.vmoptions         |
| PYCHARM_VM_OPTIONS          | 破解包路径\vmoptions\pycharm.vmoptions          |
| RIDER_VM_OPTIONS            | 破解包路径\vmoptions\rider.vmoptions            |
| RUBYMINE_VM_OPTIONS         | 破解包路径\vmoptions\rubymine.vmoptions         |
| STUDIO_VM_OPTIONS           | 破解包路径\vmoptions\studio.vmoptions           |
| WEBIDE_VM_OPTIONS           | 破解包路径\vmoptions\webide.vmoptions           |
| WEBSTORM_VM_OPTIONS         | 破解包路径\vmoptions\webstorm.vmoptions         |

	

## 激活步骤(自动激活)
- 执行/scripts文件夹下uninstall-all-users.vbs		等待弹出Done弹窗
- 执行/scripts文件夹下install-current-user.vbs	等待弹出Done弹窗
- 生成激活码
  - 通过 http://activate.jetbrains.zoyopo.cn/
- 打开需要破解的软件 选择激活码激活
- 输入第三步获取到的激活码